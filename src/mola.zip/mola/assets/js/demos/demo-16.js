// Demo 16 Js file
$(document).ready(function() {
    'use strict';
});